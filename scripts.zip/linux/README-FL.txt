# to install dep: 
# apt get install libreoffice-writer libreoffice-impress pdftk-java texlive-extra-utils
